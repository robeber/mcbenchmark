# MC Bench (working name) - Minecraft 1.21.11, Fabric - v0.2.0

A repeatable in-game benchmark: average FPS, 1% lows, stutter count and one shareable score,
plus a run comparison so you can see what one change (a mod, a setting) really did.

## Use in game
- `/mcbench start` 30 s measured after a 5 s warmup. `/mcbench start 60`, or `/mcbench start 60 spin`
  - `still`: you stay put, camera does not move (default)
  - `spin`: the camera turns a full circle every 10 s by itself (same motion every run, stand still)
- `/mcbench stop`, `/mcbench status`
- `/mcbench compare` compares your last two saved runs and lists what changed (mods, resolution, GPU...)

Each run saves two files in `.minecraft/mcbench/`:
- `result-<time>.json` all the numbers
- `report-<time>.html` a result card with a frame-time graph. Open in a browser and screenshot it to share.

Tips for fair results: same world and same spot, close other programs, run twice and compare
(under 2% difference is normal noise).

## What is measured
Average FPS, 1% and 0.1% low FPS, median / 99th percentile / longest frame time, stutters
(frames slower than twice the median and than 20 ms), garbage collection count and time,
memory, GPU name, render distance, resolution, Java, OS, CPU threads, installed mods.

Score (v1): round((0.6 x average FPS + 0.4 x 1% low FPS) x 10)

## Build without installing anything locally
1. Create a GitHub repository and upload everything in this folder (keep the folder structure).
2. Open the Actions tab. The "build" workflow runs on every upload.
3. When it is green, open the run and download the `mcbench-jar` artifact.
4. Put the jar in your mods folder together with Fabric API.

The workflow runs the plain-Java tests first, then builds the mod. If a step fails,
copy the error text from it and send it over.

## Before the first build
Check `gradle.properties` against https://fabricmc.net/develop/ for 1.21.11
(loader, loom and Fabric API versions) and update any that differ.

## Not done yet
- Fixed test world / scenes (so scores are comparable between different people, not just between your own runs)
- Results screen inside the game
- Pick a license and a mod name before publishing (fabric.mod.json says MIT and "MC Bench (working name)")
