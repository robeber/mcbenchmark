package mcbench.core;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Run with: java -cp <classes> mcbench.core.ExtraTests */
public final class ExtraTests {
    private static int failures = 0;

    public static void main(String[] args) {
        // ---- extra frame stats: 1000 frames at 5 ms, then 10 hitches at 50 ms ----
        FrameStats s = new FrameStats();
        for (int i = 0; i < 1000; i++) s.addFrame(5_000_000L);
        for (int i = 0; i < 10; i++) s.addFrame(50_000_000L);
        check("median", near(s.medianFrameMs(), 5.0, 1e-9));
        check("p99.9", near(s.percentileFrameMs(99.9), 50.0, 1e-9));
        check("longest", near(s.longestFrameMs(), 50.0, 1e-9));
        check("stutters", s.stutterCount() == 10);
        check("std dev", s.frameTimeStdDevMs() > 4.40 && s.frameTimeStdDevMs() < 4.50);
        double[] g = s.graphMaxMs(100);
        check("graph length", g.length == 100);
        check("graph start", near(g[0], 5.0, 1e-9));
        check("graph keeps the spike", near(g[99], 50.0, 1e-9));
        check("graph small runs", new FrameStats().graphMaxMs(10).length == 0);

        // fast game: 10 ms frames at 500 fps are not counted as hitches
        FrameStats fast = new FrameStats();
        for (int i = 0; i < 500; i++) fast.addFrame(2_000_000L);
        for (int i = 0; i < 5; i++) fast.addFrame(10_000_000L);
        check("no false stutters at high fps", fast.stutterCount() == 0);

        // ---- MiniJson ----
        Object o = MiniJson.parse("{\"a\": 1.5, \"b\": [1, 2, {\"c\": \"x\\ny\\u0041\"}], \"d\": true, \"e\": null}");
        Map<?, ?> m = (Map<?, ?>) o;
        check("json number", ((Double) m.get("a")) == 1.5);
        check("json array", ((List<?>) m.get("b")).size() == 3);
        check("json escapes", "x\nyA".equals(((Map<?, ?>) ((List<?>) m.get("b")).get(2)).get("c")));
        check("json bool/null", Boolean.TRUE.equals(m.get("d")) && m.get("e") == null && m.containsKey("e"));
        boolean threw = false;
        try { MiniJson.parse("{\"a\": }"); } catch (IllegalArgumentException e) { threw = true; }
        check("json rejects garbage", threw);

        // ---- round trip: result -> JSON -> summary ----
        Map<String, String> env = new LinkedHashMap<>();
        env.put("minecraft", "1.21.11");
        env.put("mods", "a, b");
        env.put("note", "has \"quotes\" and \\ slashes");
        Map<String, Double> extra = new LinkedHashMap<>();
        extra.put("gcCollections", 3.0);
        extra.put("gcTimeMs", 41.0);
        BenchmarkResult r = new BenchmarkResult("spin-30s", env, extra, s);
        RunSummary back = RunSummary.fromJson(r.toJson());
        check("round trip score", back.score == r.score());
        check("round trip scene", back.scene.equals("spin-30s"));
        check("round trip stutters", back.stutters == 10);
        check("round trip env", back.environment.get("note").equals("has \"quotes\" and \\ slashes"));
        check("json has extra", r.toJson().contains("\"gcCollections\": 3"));
        check("old files still load", RunSummary.fromJson("{\"score\": 900, \"scoreVersion\": 1, \"scene\": \"x\"}").score == 900);

        // ---- comparison ----
        Map<String, String> e1 = new LinkedHashMap<>();
        e1.put("minecraft", "1.21.11");
        e1.put("mods", "a, b");
        Map<String, String> e2 = new LinkedHashMap<>(e1);
        e2.put("mods", "a, b, sodium");
        FrameStats f100 = steady(10_000_000L, 500);
        FrameStats f120 = steady(8_333_333L, 500);
        List<String> cmp = Comparison.compare(
                RunSummary.of(new BenchmarkResult("t", e1, f100)),
                RunSummary.of(new BenchmarkResult("t", e2, f120)));
        String text = String.join("\n", cmp);
        check("compare +20%", text.contains("Score: 1000 -> 1200 (+20.0%)"));
        check("compare verdict", text.contains("Verdict: faster by 20.0%"));
        check("compare mods added", text.contains("Mods added: sodium"));
        check("compare mods only is fair", !text.contains("more than one thing"));

        List<String> same = Comparison.compare(
                RunSummary.of(new BenchmarkResult("t", e1, f100)),
                RunSummary.of(new BenchmarkResult("t", e1, steady(10_100_000L, 500))));
        String sameText = String.join("\n", same);
        check("noise verdict", sameText.contains("no real difference"));
        check("same setup", sameText.contains("Same setup"));

        Map<String, String> e3 = new LinkedHashMap<>(e1);
        e3.put("resolution", "1920x1080");
        check("settings warning", String.join("\n", Comparison.compare(
                RunSummary.of(new BenchmarkResult("t", e1, f100)),
                RunSummary.of(new BenchmarkResult("t", e3, f100)))).contains("more than one thing"));

        RunSummary v2 = new RunSummary("t", 2, 1000, 100, 100, 10, 0, e1);
        check("score version mismatch", Comparison.compare(RunSummary.of(new BenchmarkResult("t", e1, f100)), v2)
                .get(0).startsWith("Not comparable"));
        check("scene mismatch warns", String.join("\n", Comparison.compare(
                RunSummary.of(new BenchmarkResult("a", e1, f100)),
                RunSummary.of(new BenchmarkResult("b", e1, f100)))).contains("different tests"));

        // ---- HTML report ----
        Map<String, String> evil = new LinkedHashMap<>();
        evil.put("mods", "<script>alert(1)</script>");
        String html = HtmlReport.render(new BenchmarkResult("t", evil, extra, s));
        check("html has svg", html.contains("<svg") && html.contains("<polyline"));
        check("html escapes", !html.contains("<script>") && html.contains("&lt;script&gt;"));
        check("html has score", html.contains(">" + new BenchmarkResult("t", evil, s).score() + "<"));
        check("html tiny run", HtmlReport.render(new BenchmarkResult("t", env, new FrameStats())).contains("Not enough frames"));

        if (failures == 0) System.out.println("EXTRA TESTS PASSED");
        else { System.out.println(failures + " EXTRA TEST(S) FAILED"); System.exit(1); }
    }

    private static FrameStats steady(long nanos, int frames) {
        FrameStats f = new FrameStats();
        for (int i = 0; i < frames; i++) f.addFrame(nanos);
        return f;
    }

    private static boolean near(double a, double b, double tol) { return Math.abs(a - b) <= tol; }

    private static void check(String name, boolean ok) {
        if (!ok) { failures++; System.out.println("FAIL: " + name); }
    }
}
