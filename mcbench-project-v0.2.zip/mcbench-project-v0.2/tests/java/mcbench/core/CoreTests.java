package mcbench.core;

import java.util.LinkedHashMap;
import java.util.Map;

/** Plain-Java checks. Run with: java -cp out mcbench.core.CoreTests */
public final class CoreTests {
    private static int failures = 0;

    public static void main(String[] args) {
        // 1000 smooth frames at 5 ms (200 FPS) plus 10 stutters at 50 ms.
        FrameStats s = new FrameStats();
        for (int i = 0; i < 1000; i++) s.addFrame(5_000_000L);
        for (int i = 0; i < 10; i++) s.addFrame(50_000_000L);

        check("frame count", s.frameCount() == 1010);
        check("total seconds", near(s.totalSeconds(), 5.5, 1e-9));
        check("average fps", near(s.averageFps(), 1010 / 5.5, 1e-6));
        // worst 1% of 1010 frames = ceil(10.1) = 11 frames: ten 50 ms + one 5 ms
        check("1% low", near(s.onePercentLowFps(), 1000.0 / ((10 * 50 + 5) / 11.0), 1e-6));
        check("min fps", near(s.minFps(), 20.0, 1e-9));
        check("max fps", near(s.maxFps(), 200.0, 1e-9));

        // Constant frames: every stat should equal the same FPS.
        FrameStats c = new FrameStats();
        for (int i = 0; i < 500; i++) c.addFrame(10_000_000L); // 100 FPS
        check("constant avg", near(c.averageFps(), 100, 1e-9));
        check("constant 1% low", near(c.onePercentLowFps(), 100, 1e-9));
        check("constant score", Score.compute(c) == 1000);

        // Bad input and empty data must not crash.
        FrameStats e = new FrameStats();
        e.addFrame(0);
        e.addFrame(-5);
        check("empty count", e.frameCount() == 0);
        check("empty avg", e.averageFps() == 0);
        check("empty low", e.onePercentLowFps() == 0);

        // Growth past the first buffer size.
        FrameStats big = new FrameStats();
        for (int i = 0; i < 10_000; i++) big.addFrame(16_000_000L);
        check("buffer growth", big.frameCount() == 10_000);

        // Report formats.
        Map<String, String> env = new LinkedHashMap<>();
        env.put("minecraft", "test");
        env.put("note", "quote \" and backslash \\ and newline \n");
        BenchmarkResult r = new BenchmarkResult("test-scene", env, c);
        String json = r.toJson();
        check("json has score", json.contains("\"score\": 1000"));
        check("json escapes quote", json.contains("quote \\\" and backslash \\\\ and newline \\n"));
        check("text has scene", r.toText().contains("Test: test-scene"));

        System.out.println(r.toText());
        if (failures == 0) System.out.println("ALL TESTS PASSED");
        else {
            System.out.println(failures + " TEST(S) FAILED");
            System.exit(1);
        }
    }

    private static boolean near(double a, double b, double tol) {
        return Math.abs(a - b) <= tol;
    }

    private static void check(String name, boolean ok) {
        if (!ok) {
            failures++;
            System.out.println("FAIL: " + name);
        }
    }
}
