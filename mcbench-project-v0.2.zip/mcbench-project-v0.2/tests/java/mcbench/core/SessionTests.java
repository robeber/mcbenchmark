package mcbench.core;

/** Run with: java -cp <classes> mcbench.core.SessionTests */
public final class SessionTests {
    private static int failures = 0;

    public static void main(String[] args) {
        long frame = 16_666_667L; // about 60 FPS

        // 5 s warmup + 30 s measured at a steady 60 FPS.
        BenchmarkSession s = new BenchmarkSession(5, 30);
        check("idle before start", s.state() == BenchmarkSession.State.IDLE);
        check("idle ignores frames", !s.onFrame(1_000));
        long t = 1_000_000_000L;
        s.start(t);
        check("warmup after start", s.state() == BenchmarkSession.State.WARMUP);

        int finishedCount = 0;
        long end = t + 40_000_000_000L;
        boolean sawRunning = false;
        while (t < end && s.state() != BenchmarkSession.State.FINISHED) {
            t += frame;
            if (s.onFrame(t)) finishedCount++;
            if (s.state() == BenchmarkSession.State.RUNNING) sawRunning = true;
        }
        check("went through RUNNING", sawRunning);
        check("finished exactly once", finishedCount == 1);
        check("state finished", s.state() == BenchmarkSession.State.FINISHED);
        check("no more events after finish", !s.onFrame(t + frame));
        check("about 60 fps", Math.abs(s.stats().averageFps() - 60.0) < 0.5);
        check("about 1800 frames", Math.abs(s.stats().frameCount() - 1800) <= 2);
        check("warmup frames not counted", s.stats().totalSeconds() < 31);

        // Cancel.
        BenchmarkSession c = new BenchmarkSession(1, 5);
        c.start(0);
        c.onFrame(frame);
        c.cancel();
        check("cancel goes idle", c.state() == BenchmarkSession.State.IDLE);
        check("cancelled ignores frames", !c.onFrame(10_000_000_000L));

        // Time left.
        BenchmarkSession r = new BenchmarkSession(5, 30);
        r.start(0);
        check("time left at start", Math.abs(r.secondsLeft(0) - 35) < 1e-9);
        check("time left mid warmup", Math.abs(r.secondsLeft(2_000_000_000L) - 33) < 1e-9);

        // Bad settings.
        boolean threw = false;
        try { new BenchmarkSession(0, 0); } catch (IllegalArgumentException e) { threw = true; }
        check("rejects zero measure time", threw);

        if (failures == 0) System.out.println("SESSION TESTS PASSED");
        else { System.out.println(failures + " SESSION TEST(S) FAILED"); System.exit(1); }
    }

    private static void check(String name, boolean ok) {
        if (!ok) { failures++; System.out.println("FAIL: " + name); }
    }
}
