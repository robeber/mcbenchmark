package mcbench.core;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/** Compares two runs and explains what changed between them. */
public final class Comparison {
    /** Differences smaller than this are normal run-to-run noise. */
    public static final double NOISE_PERCENT = 2.0;

    private Comparison() {}

    /**
     * @param before the earlier (baseline) run
     * @param after  the newer run
     * @return lines of text, ready for chat
     */
    public static List<String> compare(RunSummary before, RunSummary after) {
        List<String> out = new ArrayList<>();
        if (before.scoreVersion != after.scoreVersion) {
            out.add(String.format(Locale.ROOT,
                    "Not comparable: scores use different formulas (v%d and v%d).",
                    before.scoreVersion, after.scoreVersion));
            return out;
        }
        if (!before.scene.equals(after.scene)) {
            out.add("Warning: different tests (" + before.scene + " vs " + after.scene
                    + "), so this may not be a fair comparison.");
        }

        out.add(metric("Score", before.score, after.score));
        out.add(metric("Average FPS", before.averageFps, after.averageFps));
        out.add(metric("1% low FPS", before.onePercentLowFps, after.onePercentLowFps));
        out.add(String.format(Locale.ROOT, "Stutters: %d -> %d", before.stutters, after.stutters));

        double change = percent(before.score, after.score);
        if (Math.abs(change) < NOISE_PERCENT) {
            out.add(String.format(Locale.ROOT,
                    "Verdict: no real difference (under %.0f%% is normal run-to-run noise).", NOISE_PERCENT));
        } else if (change > 0) {
            out.add(String.format(Locale.ROOT, "Verdict: faster by %.1f%%.", change));
        } else {
            out.add(String.format(Locale.ROOT, "Verdict: slower by %.1f%%.", -change));
        }

        out.addAll(environmentChanges(before.environment, after.environment));
        return out;
    }

    private static List<String> environmentChanges(Map<String, String> a, Map<String, String> b) {
        List<String> out = new ArrayList<>();
        boolean settingsChanged = false;

        Set<String> keys = new LinkedHashSet<>(a.keySet());
        keys.addAll(b.keySet());
        for (String key : keys) {
            String x = a.getOrDefault(key, "(none)");
            String y = b.getOrDefault(key, "(none)");
            if (x.equals(y)) continue;
            if (key.equals("mods")) {
                Set<String> before = split(x);
                Set<String> after = split(y);
                Set<String> added = new TreeSet<>(after);
                added.removeAll(before);
                Set<String> removed = new TreeSet<>(before);
                removed.removeAll(after);
                if (!added.isEmpty()) out.add("Mods added: " + String.join(", ", added));
                if (!removed.isEmpty()) out.add("Mods removed: " + String.join(", ", removed));
            } else {
                out.add("Changed " + key + ": " + x + " -> " + y);
                if (!key.equals("mcbench")) settingsChanged = true;
            }
        }
        if (out.isEmpty()) {
            out.add("Same setup in both runs.");
        } else if (settingsChanged) {
            out.add("Warning: settings or hardware differ, so more than one thing changed.");
        }
        return out;
    }

    private static Set<String> split(String mods) {
        Set<String> set = new TreeSet<>();
        if (mods.equals("(none)")) return set;
        for (String m : mods.split(",")) {
            String t = m.trim();
            if (!t.isEmpty()) set.add(t);
        }
        return set;
    }

    private static String metric(String name, double before, double after) {
        return String.format(Locale.ROOT, "%s: %.0f -> %.0f (%+.1f%%)", name, before, after, percent(before, after));
    }

    private static double percent(double before, double after) {
        if (before == 0) return 0;
        return (after - before) / before * 100.0;
    }
}
