package mcbench.core;

import java.util.Arrays;

/**
 * Collects frame times (in nanoseconds) and turns them into the numbers a
 * benchmark report needs. Pure Java: no Minecraft code, so it works on any
 * Minecraft version and can be tested without starting the game.
 */
public final class FrameStats {
    private long[] frameNanos = new long[4096];
    private int count;
    private long totalNanos;

    /** Records one frame. Zero or negative times are ignored. */
    public void addFrame(long nanos) {
        if (nanos <= 0) return;
        if (count == frameNanos.length) {
            frameNanos = Arrays.copyOf(frameNanos, count * 2);
        }
        frameNanos[count++] = nanos;
        totalNanos += nanos;
    }

    public int frameCount() {
        return count;
    }

    public double totalSeconds() {
        return totalNanos / 1_000_000_000.0;
    }

    /** Average FPS = frames rendered divided by time taken. */
    public double averageFps() {
        if (count == 0) return 0;
        return count / totalSeconds();
    }

    /**
     * FPS of the slowest frames: the average frame time of the worst
     * {@code worstFraction} of frames (for example 0.01 = worst 1%),
     * converted to FPS. This is the "stutter" number.
     */
    public double lowFps(double worstFraction) {
        if (count == 0) return 0;
        if (worstFraction <= 0 || worstFraction > 1) {
            throw new IllegalArgumentException("worstFraction must be in (0, 1]");
        }
        long[] sorted = Arrays.copyOf(frameNanos, count);
        Arrays.sort(sorted); // ascending: slowest frames are at the end
        int n = Math.max(1, (int) Math.ceil(count * worstFraction));
        long sum = 0;
        for (int i = count - n; i < count; i++) sum += sorted[i];
        double avgNanos = (double) sum / n;
        return 1_000_000_000.0 / avgNanos;
    }

    public double onePercentLowFps() {
        return lowFps(0.01);
    }

    public double pointOnePercentLowFps() {
        return lowFps(0.001);
    }

    /** FPS of the single slowest frame. */
    public double minFps() {
        if (count == 0) return 0;
        long worst = 0;
        for (int i = 0; i < count; i++) worst = Math.max(worst, frameNanos[i]);
        return 1_000_000_000.0 / worst;
    }

    /** FPS of the single fastest frame. */
    public double maxFps() {
        if (count == 0) return 0;
        long best = Long.MAX_VALUE;
        for (int i = 0; i < count; i++) best = Math.min(best, frameNanos[i]);
        return 1_000_000_000.0 / best;
    }

    /** Frame time in milliseconds at percentile p (0-100), nearest-rank method. */
    public double percentileFrameMs(double p) {
        if (count == 0) return 0;
        long[] sorted = Arrays.copyOf(frameNanos, count);
        Arrays.sort(sorted);
        int idx = (int) Math.ceil(p / 100.0 * count) - 1;
        idx = Math.max(0, Math.min(count - 1, idx));
        return sorted[idx] / 1_000_000.0;
    }

    public double medianFrameMs() {
        return percentileFrameMs(50);
    }

    public double longestFrameMs() {
        if (count == 0) return 0;
        long worst = 0;
        for (int i = 0; i < count; i++) worst = Math.max(worst, frameNanos[i]);
        return worst / 1_000_000.0;
    }

    /** Standard deviation of frame times in ms. Lower means smoother pacing. */
    public double frameTimeStdDevMs() {
        if (count == 0) return 0;
        double mean = totalNanos / (double) count / 1_000_000.0;
        double sum = 0;
        for (int i = 0; i < count; i++) {
            double d = frameNanos[i] / 1_000_000.0 - mean;
            sum += d * d;
        }
        return Math.sqrt(sum / count);
    }

    /**
     * Number of visible hitches: frames slower than both twice the median
     * frame time and 20 ms. (At very high FPS a 10 ms frame is not a hitch.)
     */
    public int stutterCount() {
        if (count == 0) return 0;
        double threshold = Math.max(2 * medianFrameMs(), 20.0);
        int n = 0;
        for (int i = 0; i < count; i++) {
            if (frameNanos[i] / 1_000_000.0 > threshold) n++;
        }
        return n;
    }

    /**
     * The run squeezed into at most {@code buckets} points for a graph. Each
     * point is the slowest frame in its slice of the run, so spikes never
     * disappear.
     */
    public double[] graphMaxMs(int buckets) {
        if (count == 0 || buckets <= 0) return new double[0];
        int b = Math.min(buckets, count);
        double[] out = new double[b];
        for (int i = 0; i < count; i++) {
            int idx = (int) ((long) i * b / count);
            out[idx] = Math.max(out[idx], frameNanos[i] / 1_000_000.0);
        }
        return out;
    }

    /** Copy of all frame times in milliseconds, in the order they happened (for graphs). */
    public double[] frameTimesMs() {
        double[] out = new double[count];
        for (int i = 0; i < count; i++) out[i] = frameNanos[i] / 1_000_000.0;
        return out;
    }
}
