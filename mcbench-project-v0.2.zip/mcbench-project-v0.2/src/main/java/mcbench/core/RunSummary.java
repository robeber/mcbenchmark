package mcbench.core;

import java.util.LinkedHashMap;
import java.util.Map;

/** The few numbers of a past run that are needed to compare it with another. */
public final class RunSummary {
    public final String scene;
    public final int scoreVersion;
    public final int score;
    public final double averageFps;
    public final double onePercentLowFps;
    public final double p99FrameMs;
    public final int stutters;
    public final Map<String, String> environment;

    public RunSummary(String scene, int scoreVersion, int score, double averageFps,
                      double onePercentLowFps, double p99FrameMs, int stutters,
                      Map<String, String> environment) {
        this.scene = scene;
        this.scoreVersion = scoreVersion;
        this.score = score;
        this.averageFps = averageFps;
        this.onePercentLowFps = onePercentLowFps;
        this.p99FrameMs = p99FrameMs;
        this.stutters = stutters;
        this.environment = new LinkedHashMap<>(environment);
    }

    public static RunSummary of(BenchmarkResult r) {
        FrameStats s = r.stats();
        return new RunSummary(r.sceneId(), Score.VERSION, r.score(), s.averageFps(),
                s.onePercentLowFps(), s.percentileFrameMs(99), s.stutterCount(), r.environment());
    }

    /** Reads a result file written by {@link BenchmarkResult#toJson()}. Older files may lack some fields. */
    @SuppressWarnings("unchecked")
    public static RunSummary fromJson(String json) {
        Object root = MiniJson.parse(json);
        if (!(root instanceof Map)) throw new IllegalArgumentException("Result file is not a JSON object");
        Map<String, Object> o = (Map<String, Object>) root;

        Map<String, String> env = new LinkedHashMap<>();
        Object envObj = o.get("environment");
        if (envObj instanceof Map) {
            for (Map.Entry<String, Object> e : ((Map<String, Object>) envObj).entrySet()) {
                env.put(e.getKey(), String.valueOf(e.getValue()));
            }
        }
        return new RunSummary(
                o.get("scene") instanceof String ? (String) o.get("scene") : "unknown",
                (int) num(o, "scoreVersion"),
                (int) num(o, "score"),
                num(o, "averageFps"),
                num(o, "onePercentLowFps"),
                num(o, "p99FrameMs"),
                (int) num(o, "stutters"),
                env);
    }

    private static double num(Map<String, Object> o, String key) {
        Object v = o.get(key);
        return v instanceof Double ? (Double) v : 0;
    }
}
