package mcbench.core;

/**
 * Turns frame stats into one shareable number.
 *
 * Score version 1: score = round((0.6 * averageFps + 0.4 * onePercentLowFps) * 10)
 *
 * Stutter (the 1% low) counts for 40% because smoothness matters as much as
 * raw speed. If this formula ever changes, VERSION must go up, so old scores
 * are never compared with new ones by mistake.
 */
public final class Score {
    public static final int VERSION = 1;

    private Score() {}

    public static int compute(FrameStats stats) {
        double value = 0.6 * stats.averageFps() + 0.4 * stats.onePercentLowFps();
        return (int) Math.round(value * 10);
    }
}
