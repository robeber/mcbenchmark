package mcbench.core;

/**
 * The timing logic of one benchmark run: a warmup period (frames ignored, so
 * chunk loading does not spoil the numbers), then a measured period.
 *
 * Pure Java. The game calls {@link #onFrame(long)} once per frame with
 * System.nanoTime().
 */
public final class BenchmarkSession {
    public enum State { IDLE, WARMUP, RUNNING, FINISHED }

    private final long warmupNanos;
    private final long measureNanos;
    private final FrameStats stats = new FrameStats();

    private State state = State.IDLE;
    private long startNanos;
    private long measureStartNanos;
    private long lastFrameNanos;

    public BenchmarkSession(double warmupSeconds, double measureSeconds) {
        if (warmupSeconds < 0 || measureSeconds <= 0) {
            throw new IllegalArgumentException("warmup must be >= 0 and measure must be > 0");
        }
        this.warmupNanos = (long) (warmupSeconds * 1_000_000_000L);
        this.measureNanos = (long) (measureSeconds * 1_000_000_000L);
    }

    public void start(long nowNanos) {
        state = State.WARMUP;
        startNanos = nowNanos;
        lastFrameNanos = 0;
    }

    /** Stops early. The numbers gathered so far are discarded by the caller. */
    public void cancel() {
        state = State.IDLE;
    }

    /**
     * Call once per frame.
     *
     * @return true exactly once, on the frame where the measured period ends
     */
    public boolean onFrame(long nowNanos) {
        if (state != State.WARMUP && state != State.RUNNING) return false;

        long frameTime = lastFrameNanos == 0 ? 0 : nowNanos - lastFrameNanos;
        lastFrameNanos = nowNanos;

        if (state == State.WARMUP) {
            if (nowNanos - startNanos >= warmupNanos) {
                state = State.RUNNING;
                measureStartNanos = nowNanos;
            }
            return false;
        }

        stats.addFrame(frameTime); // a zero frame time is ignored by FrameStats
        if (nowNanos - measureStartNanos >= measureNanos) {
            state = State.FINISHED;
            return true;
        }
        return false;
    }

    public State state() {
        return state;
    }

    public boolean isActive() {
        return state == State.WARMUP || state == State.RUNNING;
    }

    public FrameStats stats() {
        return stats;
    }

    /** Seconds since start() (warmup included). Used to drive a scripted camera. */
    public double elapsedSeconds(long nowNanos) {
        return isActive() ? (nowNanos - startNanos) / 1e9 : 0;
    }

    /** Seconds until the run ends (warmup included), never negative. */
    public double secondsLeft(long nowNanos) {
        switch (state) {
            case WARMUP: {
                double warm = (startNanos + warmupNanos - nowNanos) / 1e9;
                return Math.max(0, warm) + measureNanos / 1e9;
            }
            case RUNNING:
                return Math.max(0, (measureStartNanos + measureNanos - nowNanos) / 1e9);
            default:
                return 0;
        }
    }
}
