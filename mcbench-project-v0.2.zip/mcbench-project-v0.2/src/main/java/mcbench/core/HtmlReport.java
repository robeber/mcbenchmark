package mcbench.core;

import java.util.Locale;
import java.util.Map;

/** Builds a self-contained HTML result card (no internet needed) that can be opened in a browser and screenshotted. */
public final class HtmlReport {
    private HtmlReport() {}

    public static String render(BenchmarkResult r) {
        FrameStats s = r.stats();
        StringBuilder h = new StringBuilder(8192);
        h.append("<!doctype html>\n<html lang=\"en\"><head><meta charset=\"utf-8\">\n")
         .append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n")
         .append("<title>MC Bench - score ").append(r.score()).append("</title>\n<style>\n")
         .append(":root{--bg:#0f1115;--card:#171a21;--text:#e8eaf0;--muted:#8b93a7;--accent:#5eead4;--warn:#fbbf24;--line:#2a2f3a}\n")
         .append("@media (prefers-color-scheme: light){:root{--bg:#f4f5f7;--card:#fff;--text:#14171f;--muted:#5b6478;--accent:#0f766e;--warn:#b45309;--line:#dde1e8}}\n")
         .append("*{box-sizing:border-box}body{margin:0;padding:24px;background:var(--bg);color:var(--text);font:16px/1.5 system-ui,-apple-system,'Segoe UI',Roboto,sans-serif}\n")
         .append(".wrap{max-width:760px;margin:0 auto}.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:20px;margin-bottom:16px}\n")
         .append("h1{font-size:14px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin:0 0 4px;font-weight:600}\n")
         .append(".score{font-size:64px;font-weight:700;color:var(--accent);line-height:1.1}.sub{color:var(--muted);font-size:14px}\n")
         .append(".grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}\n")
         .append(".stat .v{font-size:24px;font-weight:600}.stat .l{color:var(--muted);font-size:13px}\n")
         .append("table{width:100%;border-collapse:collapse;font-size:14px}td{padding:6px 0;border-top:1px solid var(--line);vertical-align:top}td:first-child{color:var(--muted);width:38%;padding-right:12px}td:last-child{word-break:break-word}\n")
         .append("h2{font-size:15px;margin:0 0 12px}svg{width:100%;height:auto;display:block}\n")
         .append("</style></head><body><div class=\"wrap\">\n");

        h.append("<div class=\"card\"><h1>MC Bench</h1><div class=\"score\">").append(r.score()).append("</div>")
         .append("<div class=\"sub\">Test: ").append(esc(r.sceneId())).append(" &middot; score formula v")
         .append(Score.VERSION).append("</div></div>\n");

        h.append("<div class=\"card\"><div class=\"grid\">");
        stat(h, "Average FPS", f0(s.averageFps()));
        stat(h, "1% low FPS", f0(s.onePercentLowFps()));
        stat(h, "0.1% low FPS", f0(s.pointOnePercentLowFps()));
        stat(h, "Median frame", f2(s.medianFrameMs()) + " ms");
        stat(h, "99th percentile frame", f2(s.percentileFrameMs(99)) + " ms");
        stat(h, "Longest frame", f1(s.longestFrameMs()) + " ms");
        stat(h, "Stutters", String.valueOf(s.stutterCount()));
        stat(h, "Frames", String.valueOf(s.frameCount()));
        stat(h, "Measured time", f1(s.totalSeconds()) + " s");
        h.append("</div></div>\n");

        h.append("<div class=\"card\"><h2>Frame time during the run (slowest frame per slice, lower is better)</h2>");
        graph(h, s);
        h.append("</div>\n");

        if (!r.extras().isEmpty()) {
            h.append("<div class=\"card\"><h2>Extra measurements</h2><table>");
            for (Map.Entry<String, Double> e : r.extras().entrySet()) {
                h.append("<tr><td>").append(esc(e.getKey())).append("</td><td>")
                 .append(BenchmarkResult.num(e.getValue())).append("</td></tr>");
            }
            h.append("</table></div>\n");
        }

        h.append("<div class=\"card\"><h2>Setup</h2><table>");
        for (Map.Entry<String, String> e : r.environment().entrySet()) {
            h.append("<tr><td>").append(esc(e.getKey())).append("</td><td>")
             .append(esc(e.getValue())).append("</td></tr>");
        }
        h.append("</table></div>\n");

        h.append("<div class=\"sub\">Score = round((0.6 &times; average FPS + 0.4 &times; 1% low FPS) &times; 10). ")
         .append("A stutter is a frame slower than twice the median and slower than 20 ms.</div>\n")
         .append("</div></body></html>\n");
        return h.toString();
    }

    private static void graph(StringBuilder h, FrameStats s) {
        double[] g = s.graphMaxMs(BenchmarkResult.GRAPH_POINTS);
        final double w = 720, ht = 200;
        if (g.length < 2) {
            h.append("<div class=\"sub\">Not enough frames to draw a graph.</div>");
            return;
        }
        double yMax = Math.max(40.0, s.percentileFrameMs(99) * 4);
        double top = 0;
        for (double v : g) top = Math.max(top, v);
        yMax = Math.min(yMax, Math.max(top, 20.0));
        yMax = Math.max(yMax, 20.0);

        h.append(String.format(Locale.ROOT, "<svg viewBox=\"0 0 %.0f %.0f\" role=\"img\" aria-label=\"Frame time graph\">", w, ht + 18));
        for (double[] ref : new double[][]{{1000.0 / 60, 60}, {1000.0 / 30, 30}}) {
            if (ref[0] >= yMax) continue;
            double y = ht - ref[0] / yMax * ht;
            h.append(String.format(Locale.ROOT,
                    "<line x1=\"0\" y1=\"%.1f\" x2=\"%.0f\" y2=\"%.1f\" stroke=\"var(--line)\" stroke-dasharray=\"4 4\"/>"
                            + "<text x=\"4\" y=\"%.1f\" font-size=\"11\" fill=\"var(--muted)\">%.0f FPS</text>",
                    y, w, y, y - 3, ref[1]));
        }
        StringBuilder pts = new StringBuilder();
        for (int i = 0; i < g.length; i++) {
            double x = i * w / (g.length - 1);
            double y = ht - Math.min(g[i], yMax) / yMax * ht;
            pts.append(String.format(Locale.ROOT, "%.1f,%.1f ", x, y));
        }
        h.append("<polyline fill=\"none\" stroke=\"var(--accent)\" stroke-width=\"1.6\" stroke-linejoin=\"round\" points=\"")
         .append(pts).append("\"/>");
        h.append(String.format(Locale.ROOT,
                "<text x=\"4\" y=\"%.0f\" font-size=\"11\" fill=\"var(--muted)\">start</text>"
                        + "<text x=\"%.0f\" y=\"%.0f\" font-size=\"11\" text-anchor=\"end\" fill=\"var(--muted)\">end &middot; graph top = %.0f ms</text>",
                ht + 14, w - 4, ht + 14, yMax));
        h.append("</svg>");
    }

    private static void stat(StringBuilder h, String label, String value) {
        h.append("<div class=\"stat\"><div class=\"v\">").append(esc(value)).append("</div><div class=\"l\">")
         .append(esc(label)).append("</div></div>");
    }

    private static String f0(double v) { return String.format(Locale.ROOT, "%.0f", v); }
    private static String f1(double v) { return String.format(Locale.ROOT, "%.1f", v); }
    private static String f2(double v) { return String.format(Locale.ROOT, "%.2f", v); }

    static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
