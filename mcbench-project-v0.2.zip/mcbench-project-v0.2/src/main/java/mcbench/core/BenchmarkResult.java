package mcbench.core;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * One finished benchmark run: which test was run, the environment it ran in,
 * extra measurements (like garbage collection), and the frame statistics.
 */
public final class BenchmarkResult {
    public static final int GRAPH_POINTS = 120;

    private final String sceneId;
    private final Map<String, String> environment;
    private final Map<String, Double> extras;
    private final FrameStats stats;

    /**
     * @param sceneId     name of the test, for example "spin-30s"
     * @param environment things that affect results: game version, render distance,
     *                    resolution, GPU, mods installed, Java memory, and so on
     * @param extras      extra numbers measured during the run (garbage collection, ...)
     */
    public BenchmarkResult(String sceneId, Map<String, String> environment,
                           Map<String, Double> extras, FrameStats stats) {
        this.sceneId = sceneId;
        this.environment = new LinkedHashMap<>(environment);
        this.extras = new LinkedHashMap<>(extras);
        this.stats = stats;
    }

    public BenchmarkResult(String sceneId, Map<String, String> environment, FrameStats stats) {
        this(sceneId, environment, Collections.emptyMap(), stats);
    }

    public String sceneId() { return sceneId; }
    public Map<String, String> environment() { return Collections.unmodifiableMap(environment); }
    public Map<String, Double> extras() { return Collections.unmodifiableMap(extras); }
    public FrameStats stats() { return stats; }

    public int score() {
        return Score.compute(stats);
    }

    /** Short text for chat. */
    public String toText() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(Locale.ROOT, "Benchmark score: %d (v%d)%n", score(), Score.VERSION));
        sb.append(String.format(Locale.ROOT, "Test: %s%n", sceneId));
        sb.append(String.format(Locale.ROOT, "Average FPS: %.1f%n", stats.averageFps()));
        sb.append(String.format(Locale.ROOT, "1%% low FPS: %.1f   0.1%% low FPS: %.1f%n",
                stats.onePercentLowFps(), stats.pointOnePercentLowFps()));
        sb.append(String.format(Locale.ROOT, "Frame time: median %.2f ms, 99th percentile %.2f ms, longest %.1f ms%n",
                stats.medianFrameMs(), stats.percentileFrameMs(99), stats.longestFrameMs()));
        sb.append(String.format(Locale.ROOT, "Stutters (visible hitches): %d%n", stats.stutterCount()));
        sb.append(String.format(Locale.ROOT, "Frames: %d in %.1fs%n", stats.frameCount(), stats.totalSeconds()));
        for (Map.Entry<String, Double> e : extras.entrySet()) {
            sb.append(e.getKey()).append(": ").append(num(e.getValue())).append('\n');
        }
        return sb.toString();
    }

    /** JSON with no outside libraries needed. */
    public String toJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"scoreVersion\": ").append(Score.VERSION).append(",\n");
        sb.append("  \"score\": ").append(score()).append(",\n");
        sb.append("  \"scene\": ").append(quote(sceneId)).append(",\n");
        field(sb, "averageFps", stats.averageFps());
        field(sb, "onePercentLowFps", stats.onePercentLowFps());
        field(sb, "pointOnePercentLowFps", stats.pointOnePercentLowFps());
        field(sb, "minFps", stats.minFps());
        field(sb, "maxFps", stats.maxFps());
        field(sb, "p50FrameMs", stats.percentileFrameMs(50));
        field(sb, "p95FrameMs", stats.percentileFrameMs(95));
        field(sb, "p99FrameMs", stats.percentileFrameMs(99));
        field(sb, "longestFrameMs", stats.longestFrameMs());
        field(sb, "frameTimeStdDevMs", stats.frameTimeStdDevMs());
        sb.append("  \"stutters\": ").append(stats.stutterCount()).append(",\n");
        sb.append("  \"frames\": ").append(stats.frameCount()).append(",\n");
        field(sb, "durationSeconds", stats.totalSeconds());

        sb.append("  \"graphMaxFrameMs\": [");
        double[] graph = stats.graphMaxMs(GRAPH_POINTS);
        for (int i = 0; i < graph.length; i++) {
            if (i > 0) sb.append(", ");
            sb.append(String.format(Locale.ROOT, "%.2f", graph[i]));
        }
        sb.append("],\n");

        sb.append("  \"extra\": {");
        boolean first = true;
        for (Map.Entry<String, Double> e : extras.entrySet()) {
            sb.append(first ? "\n" : ",\n");
            sb.append("    ").append(quote(e.getKey())).append(": ").append(num(e.getValue()));
            first = false;
        }
        sb.append(first ? "},\n" : "\n  },\n");

        sb.append("  \"environment\": {");
        first = true;
        for (Map.Entry<String, String> e : environment.entrySet()) {
            sb.append(first ? "\n" : ",\n");
            sb.append("    ").append(quote(e.getKey())).append(": ").append(quote(e.getValue()));
            first = false;
        }
        sb.append(first ? "}\n" : "\n  }\n");
        sb.append("}\n");
        return sb.toString();
    }

    private static void field(StringBuilder sb, String name, double value) {
        sb.append(String.format(Locale.ROOT, "  \"%s\": %.2f,%n", name, value));
    }

    static String num(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return Long.toString((long) v);
        return String.format(Locale.ROOT, "%.2f", v);
    }

    static String quote(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
                }
            }
        }
        return sb.append('"').toString();
    }
}
