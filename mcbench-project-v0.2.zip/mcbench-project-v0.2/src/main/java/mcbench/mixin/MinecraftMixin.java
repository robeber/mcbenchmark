package mcbench.mixin;

import mcbench.McBenchClient;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Runs once at the start of every frame. The time between two of these calls
 * is one full frame (game logic, rendering and waiting for the GPU).
 */
@Mixin(Minecraft.class)
public class MinecraftMixin {
    @Inject(method = "runTick", at = @At("HEAD"))
    private void mcbench$onFrameStart(boolean renderLevel, CallbackInfo ci) {
        McBenchClient.onFrame();
    }
}
