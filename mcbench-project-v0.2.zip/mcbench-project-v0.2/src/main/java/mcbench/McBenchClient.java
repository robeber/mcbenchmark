package mcbench;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import mcbench.core.BenchmarkResult;
import mcbench.core.BenchmarkSession;
import mcbench.core.Comparison;
import mcbench.core.HtmlReport;
import mcbench.core.RunSummary;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Client entry point. Commands:
 *   /mcbench start [seconds] [still|spin]   default 30 s, still. 5 s warmup first.
 *   /mcbench stop
 *   /mcbench status
 *   /mcbench compare      compares your last two saved runs
 *
 * All timing, statistics, comparison and report code lives in mcbench.core
 * (plain Java, unit tested). This class only connects it to the game.
 */
public final class McBenchClient implements ClientModInitializer {
    public static final String MOD_ID = "mcbench";
    private static final double WARMUP_SECONDS = 5;
    private static final int DEFAULT_SECONDS = 30;
    /** In spin mode the camera turns one full circle this often. Fixed, so every run sees the same motion. */
    private static final double SPIN_PERIOD_SECONDS = 10;
    private static final float SPIN_PITCH = 10f;

    private enum Mode {
        STILL, SPIN;

        static Mode parse(String s) {
            for (Mode m : values()) if (m.name().equalsIgnoreCase(s)) return m;
            return null;
        }
    }

    private static BenchmarkSession session;
    private static int measureSeconds;
    private static Mode mode = Mode.STILL;
    private static float spinStartYaw;
    private static boolean gcTaken;
    private static long gcCountStart;
    private static long gcTimeStart;

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("mcbench")
                        .then(ClientCommandManager.literal("start")
                                .executes(ctx -> start(DEFAULT_SECONDS, Mode.STILL))
                                .then(ClientCommandManager.argument("seconds", IntegerArgumentType.integer(5, 600))
                                        .executes(ctx -> start(IntegerArgumentType.getInteger(ctx, "seconds"), Mode.STILL))
                                        .then(ClientCommandManager.argument("mode", StringArgumentType.word())
                                                .executes(ctx -> {
                                                    Mode m = Mode.parse(StringArgumentType.getString(ctx, "mode"));
                                                    if (m == null) {
                                                        say("Unknown mode. Use: still or spin.");
                                                        return 0;
                                                    }
                                                    return start(IntegerArgumentType.getInteger(ctx, "seconds"), m);
                                                }))))
                        .then(ClientCommandManager.literal("stop").executes(ctx -> stop()))
                        .then(ClientCommandManager.literal("status").executes(ctx -> status()))
                        .then(ClientCommandManager.literal("compare").executes(ctx -> compare()))));
    }

    /** Called once per frame by MinecraftMixin, on the render thread. */
    public static void onFrame() {
        BenchmarkSession s = session;
        if (s == null || !s.isActive()) return;
        long now = System.nanoTime();
        Minecraft mc = Minecraft.getInstance();

        // Scripted camera: a fixed turn rate based on time, not frames, so every PC follows the same path.
        if (mode == Mode.SPIN && mc.player != null) {
            double turns = s.elapsedSeconds(now) / SPIN_PERIOD_SECONDS;
            mc.player.setYRot((float) (spinStartYaw + 360.0 * turns));
            mc.player.setXRot(SPIN_PITCH);
        }

        if (s.onFrame(now)) {
            session = null;
            finish(s);
        } else if (s.state() == BenchmarkSession.State.RUNNING && !gcTaken) {
            long[] gc = gcSnapshot();
            gcCountStart = gc[0];
            gcTimeStart = gc[1];
            gcTaken = true;
        }
    }

    private static int start(int seconds, Mode chosen) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            say("Join a world first, then run /mcbench start.");
            return 0;
        }
        if (session != null && session.isActive()) {
            say("A benchmark is already running. Use /mcbench stop to cancel it.");
            return 0;
        }
        measureSeconds = seconds;
        mode = chosen;
        spinStartYaw = mc.player.getYRot();
        gcTaken = false;
        session = new BenchmarkSession(WARMUP_SECONDS, seconds);
        session.start(System.nanoTime());
        String how = chosen == Mode.SPIN
                ? "The camera will turn in circles by itself, so stand still."
                : "Stay in the same spot and keep the view steady.";
        say(String.format(Locale.ROOT, "Benchmark started: %.0f s warmup, then %d s measured (%s). %s",
                WARMUP_SECONDS, seconds, chosen.name().toLowerCase(Locale.ROOT), how));
        return 1;
    }

    private static int stop() {
        if (session == null || !session.isActive()) {
            say("No benchmark is running.");
            return 0;
        }
        session.cancel();
        session = null;
        say("Benchmark cancelled.");
        return 1;
    }

    private static int status() {
        if (session == null || !session.isActive()) {
            say("No benchmark is running. Use /mcbench start.");
            return 0;
        }
        say(String.format(Locale.ROOT, "Benchmark running, about %.0f s left.",
                session.secondsLeft(System.nanoTime())));
        return 1;
    }

    private static int compare() {
        Path dir = FabricLoader.getInstance().getGameDir().resolve(MOD_ID);
        List<Path> files = new ArrayList<>();
        if (Files.isDirectory(dir)) {
            try (Stream<Path> list = Files.list(dir)) {
                files = list.filter(p -> {
                    String n = p.getFileName().toString();
                    return n.startsWith("result-") && n.endsWith(".json");
                }).sorted().collect(Collectors.toList());
            } catch (IOException e) {
                say("Could not read the results folder: " + e.getMessage());
                return 0;
            }
        }
        if (files.size() < 2) {
            say("You need at least two saved runs. Run /mcbench start twice, changing one thing in between.");
            return 0;
        }
        Path before = files.get(files.size() - 2);
        Path after = files.get(files.size() - 1);
        try {
            RunSummary a = RunSummary.fromJson(Files.readString(before, StandardCharsets.UTF_8));
            RunSummary b = RunSummary.fromJson(Files.readString(after, StandardCharsets.UTF_8));
            say("Comparing " + before.getFileName() + " (before) with " + after.getFileName() + " (after):");
            for (String line : Comparison.compare(a, b)) say(line);
            return 1;
        } catch (IOException | IllegalArgumentException e) {
            say("Could not compare the runs: " + e.getMessage());
            return 0;
        }
    }

    private static void finish(BenchmarkSession s) {
        Minecraft mc = Minecraft.getInstance();

        Map<String, Double> extras = new LinkedHashMap<>();
        long[] gc = gcSnapshot();
        extras.put("gcCollections", (double) Math.max(0, gc[0] - gcCountStart));
        extras.put("gcTimeMs", (double) Math.max(0, gc[1] - gcTimeStart));
        Runtime rt = Runtime.getRuntime();
        extras.put("usedMemoryEndMb", (double) ((rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)));

        String scene = mode.name().toLowerCase(Locale.ROOT) + "-" + measureSeconds + "s";
        BenchmarkResult result = new BenchmarkResult(scene, environment(mc), extras, s.stats());

        for (String line : result.toText().split("\n")) say(line);

        try {
            Path dir = FabricLoader.getInstance().getGameDir().resolve(MOD_ID);
            Files.createDirectories(dir);
            String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
            Files.writeString(dir.resolve("result-" + stamp + ".json"), result.toJson(), StandardCharsets.UTF_8);
            Files.writeString(dir.resolve("report-" + stamp + ".html"), HtmlReport.render(result), StandardCharsets.UTF_8);
            say("Saved in the " + MOD_ID + " folder: result-" + stamp + ".json and report-" + stamp
                    + ".html (open the report in a browser).");
        } catch (IOException e) {
            say("Could not save the results files: " + e.getMessage());
        }
    }

    /** Things that change the numbers, so two results can be compared fairly. */
    private static Map<String, String> environment(Minecraft mc) {
        Map<String, String> env = new LinkedHashMap<>();
        env.put("minecraft", modVersion("minecraft"));
        env.put("fabricLoader", modVersion("fabricloader"));
        env.put("mcbench", modVersion(MOD_ID));
        env.put("gpu", gpuName());
        env.put("renderDistance", String.valueOf(mc.options.renderDistance().get()));
        env.put("resolution", mc.getWindow().getWidth() + "x" + mc.getWindow().getHeight());
        env.put("java", System.getProperty("java.version", "unknown"));
        env.put("maxMemoryMb", String.valueOf(Runtime.getRuntime().maxMemory() / (1024 * 1024)));
        env.put("os", System.getProperty("os.name", "unknown"));
        env.put("cpuThreads", String.valueOf(Runtime.getRuntime().availableProcessors()));
        env.put("mods", FabricLoader.getInstance().getAllMods().stream()
                .map(m -> m.getMetadata().getId())
                .filter(id -> !id.startsWith("fabric-") && !id.equals("java")
                        && !id.equals("minecraft") && !id.equals("fabricloader"))
                .sorted()
                .collect(Collectors.joining(", ")));
        return env;
    }

    /** Asks OpenGL for the graphics card name. Must run on the render thread, which it does. */
    private static String gpuName() {
        try {
            String name = GL11.glGetString(GL11.GL_RENDERER);
            return name == null ? "unknown" : name;
        } catch (Throwable t) {
            return "unknown";
        }
    }

    private static long[] gcSnapshot() {
        long count = 0, time = 0;
        for (GarbageCollectorMXBean bean : ManagementFactory.getGarbageCollectorMXBeans()) {
            if (bean.getCollectionCount() > 0) count += bean.getCollectionCount();
            if (bean.getCollectionTime() > 0) time += bean.getCollectionTime();
        }
        return new long[]{count, time};
    }

    private static String modVersion(String id) {
        return FabricLoader.getInstance().getModContainer(id)
                .map(c -> c.getMetadata().getVersion().getFriendlyString())
                .orElse("unknown");
    }

    private static void say(String text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.literal(text), false);
        }
    }
}
